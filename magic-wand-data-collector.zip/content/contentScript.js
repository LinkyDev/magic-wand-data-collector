const extensionApi = typeof browser !== "undefined" ? browser : chrome;

const MESSAGE_TYPES = {
  GET_STATE: "getContentState",
  UPDATE_VALUE: "saveCapturedData",
  SET_AUTO_NAVIGATE: "setAutoNavigate",
  NAVIGATE_MANUAL: "navigateManual",
  UPDATE_INPUT_VALUE: "updateInputValue",
  SAVE_AND_EXIT: "saveAndExit",
  GET_DEBUG_FLAGS: "getDebugFlags"
};

let uiRoot = null;
let shadow = null;
let state = null;
let wandActive = false;
let autoNavigate = true;
let lastHighlighted = null;
const WAND_MODES = {
  AUTO: "auto",
  MANUAL: "manual"
};
let wandMode = WAND_MODES.AUTO;
let manualSelectionPending = false;
let manualSelectionText = "";
let autoCollectService = null;
const dragState = {
  active: false,
  pointerId: null,
  offsetX: 0,
  offsetY: 0,
  target: null
};

const LUCIDE_CURSOR_COLOR = "#5c2ec9";
// Lucide wand + sparkles path (ISC license). Falling back to URI encoding if base64 isn't available.
const WAND_CURSOR_SVG = `
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="${LUCIDE_CURSOR_COLOR}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="m21 3-6 6" />
    <path d="m3 21 6-6" />
    <path d="m15 9 2 2" />
    <path d="m9 15 2 2" />
    <path d="M11 7V5" />
    <path d="M13 7V5" />
    <path d="M12 6h2" />
    <path d="M12 6h-2" />
    <path d="M18 12v-2" />
    <path d="M18 12h2" />
    <path d="M4 8H2" />
    <path d="M5 9V7" />
  </svg>
`.replace(/\s+/g, " ").trim();
let WAND_CURSOR_DECL = "";
try {
  if (typeof btoa === "function") {
    WAND_CURSOR_DECL = `url("data:image/svg+xml;base64,${btoa(WAND_CURSOR_SVG)}") 10 10, crosshair`;
  }
} catch (error) {
  // Ignore and fall back to URI encoding.
}
if (!WAND_CURSOR_DECL) {
  WAND_CURSOR_DECL = `url("data:image/svg+xml,${encodeURIComponent(WAND_CURSOR_SVG)}") 10 10, crosshair`;
}
const MANUAL_CURSOR_DECL = 'url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http://www.w3.org/2000/svg%22%20viewBox%3D%220%200%2032%2032%22%3E%3Cpath%20fill%3D%22%23c27e1d%22%20d%3D%22M4%2024l8-8%206%206-8%208H4z%22/%3E%3Cpath%20fill%3D%22%23261b0a%22%20d%3D%22M19.8%206.2l6%206-9.6%209.6-6-6z"/%3E%3Cpath%20fill%3D%22%23f2d09f%22%20d%3D%22M24.6%2011l-3.6-3.6%202.8-2.8c.8-.8%202.1-.8%202.9%200l.7.7c.8.8.8%202.1%200%202.9z"/%3E%3C/svg%3E") 6 6, text';

const styles = `
  :host {
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 2147483647;
    font-family: "Segoe UI", Roboto, sans-serif;
    color: #1c1c28;
  }
  .mw-panel {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 12px;
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
    padding: 14px;
    width: 280px;
    display: flex;
    flex-direction: column;
    gap: 12px;
    border: 1px solid rgba(93, 99, 118, 0.2);
    backdrop-filter: blur(6px);
  }
  .mw-panel-wrapper {
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 2147483646;
  }
  .mw-row-title {
    font-weight: 600;
    font-size: 15px;
    color: #3a3a47;
  }
  .mw-controls {
    display: grid;
    gap: 8px;
  }
  .mw-toggle {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: rgba(92, 46, 201, 0.1);
    border-radius: 8px;
    padding: 8px 10px;
  }
  .mw-toggle button,
  .mw-secondary button {
    border: none;
    padding: 6px 10px;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 600;
  }
  .mw-toggle button.primary {
    background: #5c2ec9;
    color: #fff;
  }
  .mw-toggle button.secondary {
    background: transparent;
    color: #5c2ec9;
  }
  .mw-secondary {
    display: flex;
    gap: 8px;
  }
  .mw-secondary button {
    flex: 1;
    background: rgba(92, 46, 201, 0.15);
    color: #5c2ec9;
  }
  .mw-secondary button[disabled] {
    opacity: 0.4;
    cursor: not-allowed;
  }
  .mw-danger {
    background: #c2302c;
    color: #fff;
    font-weight: 600;
  }
  .mw-danger:hover {
    background: #a22622;
  }
  .mw-danger:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
  .mw-hidden {
    display: none !important;
  }
  .mw-mode {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 6px;
    padding: 6px;
    border-radius: 8px;
    background: rgba(92, 46, 201, 0.1);
  }
  .mw-mode button {
    border: none;
    border-radius: 6px;
    padding: 6px 8px;
    font-weight: 600;
    cursor: pointer;
    background: transparent;
    color: #5c2ec9;
    transition: background 0.2s ease, color 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }
  .mw-mode button.active {
    background: #5c2ec9;
    color: #fff;
  }
  .mw-mode button[disabled] {
    cursor: default;
    opacity: 0.85;
  }
  .mw-toast {
    padding: 10px 12px;
    background: rgba(92, 46, 201, 0.12);
    border-radius: 8px;
    font-size: 14px;
  }
  .mw-modal {
    position: fixed;
    top: 16px;
    right: 308px;
    width: 280px;
    border-radius: 12px;
    background: rgba(255, 255, 255, 0.95);
    box-shadow: 0 12px 32px rgba(0, 0, 0, 0.15);
    border: 1px solid rgba(93, 99, 118, 0.2);
    backdrop-filter: blur(6px);
    display: flex;
    flex-direction: column;
    max-height: 60vh;
  }
  .mw-modal header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 14px;
    border-bottom: 1px solid rgba(93, 99, 118, 0.2);
    cursor: grab;
    user-select: none;
  }
  .mw-modal header h2 {
    margin: 0;
    font-size: 14px;
  }
  .mw-modal header button {
    border: none;
    background: transparent;
    cursor: pointer;
    font-weight: 600;
    color: #5c2ec9;
  }
  .mw-modal.dragging header {
    cursor: grabbing;
  }
  .mw-modal[hidden] {
    display: none;
  }
  .mw-modal .mw-body {
    padding: 12px 14px;
    overflow: auto;
    display: grid;
    gap: 10px;
  }
  .mw-collapsed {
    display: none;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 12px 14px;
    border-top: 1px solid rgba(93, 99, 118, 0.2);
    background: rgba(92, 46, 201, 0.08);
  }
  .mw-collapsed span {
    flex: 1;
    font-size: 13px;
    font-weight: 600;
    color: #3a3a47;
  }
  .mw-collapsed button {
    border: none;
    border-radius: 6px;
    padding: 6px 10px;
    cursor: pointer;
    background: #5c2ec9;
    color: #fff;
    font-weight: 600;
  }
  .mw-modal[data-collapsed="true"] header,
  .mw-modal[data-collapsed="true"] .mw-body {
    display: none;
  }
  .mw-modal[data-collapsed="true"] .mw-collapsed {
    display: flex;
  }
  .mw-entry {
    display: grid;
    gap: 6px;
  }
  .mw-entry label {
    font-size: 13px;
    font-weight: 600;
  }
  .mw-entry textarea {
    min-height: 48px;
    border-radius: 6px;
    border: 1px solid rgba(93, 99, 118, 0.35);
    padding: 6px 8px;
    font-family: inherit;
  }
  .mw-hint {
    font-size: 12px;
    color: #5c2ec9;
  }
  .mw-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 12px;
    color: #5c2ec9;
  }
  .mw-badge::before {
    content: "•";
    display: inline-block;
    color: #5c2ec9;
  }
  .mw-hotkey {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 18px;
    height: 18px;
    padding: 0 4px;
    border-radius: 999px;
    border: 1px solid rgba(92, 46, 201, 0.2);
    background: rgba(92, 46, 201, 0.15);
    color: #5c2ec9;
    font-size: 11px;
    font-weight: 700;
    line-height: 1;
    cursor: help;
  }
  .mw-highlight {
    outline: 2px dashed #5c2ec9;
    background: rgba(92, 46, 201, 0.08);
    cursor: crosshair;
  }
`;

function ensureGlobalStyles() {
  if (document.getElementById("mw-global-style")) {
    return;
  }
  const style = document.createElement("style");
  style.id = "mw-global-style";
  style.textContent = `
    .mw-highlight {
      outline: 2px dashed #5c2ec9 !important;
      background: rgba(92, 46, 201, 0.12) !important;
      transition: outline-color 0.1s ease;
    }
    html[data-mw-wand="auto"] {
      cursor: ${WAND_CURSOR_DECL} !important;
    }
    html[data-mw-wand="auto"] * {
      cursor: ${WAND_CURSOR_DECL} !important;
    }
    html[data-mw-wand="manual"] {
      cursor: ${MANUAL_CURSOR_DECL} !important;
    }
    html[data-mw-wand="manual"] * {
      cursor: ${MANUAL_CURSOR_DECL} !important;
    }
  `;
  const host = document.head || document.documentElement;
  host.appendChild(style);
}

function ensureUi() {
  if (uiRoot) {
    return;
  }
  ensureGlobalStyles();
  uiRoot = document.createElement("div");
  shadow = uiRoot.attachShadow({ mode: "open" });
  const style = document.createElement("style");
  style.textContent = styles;
  shadow.appendChild(style);

  const panel = document.createElement("div");
  panel.className = "mw-panel";
  panel.innerHTML = `
    <div class="mw-controls">
      <div class="mw-toggle">
        <span class="mw-badge">Magic wand <span class="mw-hotkey" title="Shortcut: 3">3</span></span>
        <button id="toggle-wand" class="secondary">Disabled</button>
      </div>
      <div class="mw-toggle">
        <span class="mw-badge">Auto next</span>
        <button id="toggle-auto" class="primary">On</button>
      </div>
      <div class="mw-mode" id="mode-picker">
        <button id="mode-auto" class="active" title="Shortcut: 1">Auto click <span class="mw-hotkey" aria-hidden="true">1</span></button>
        <button id="mode-manual" title="Shortcut: 2">Manual select <span class="mw-hotkey" aria-hidden="true">2</span></button>
      </div>
      <div class="mw-secondary" id="manual-nav" hidden>
        <button id="prev-row">Prev</button>
        <button id="next-row">Next</button>
      </div>
      <button id="save-exit" class="mw-danger">Save & Exit</button>
    </div>
    <div class="mw-toast" id="row-info">Row</div>
  `;

  const panelWrapper = document.createElement("div");
  panelWrapper.className = "mw-panel-wrapper";
  panelWrapper.appendChild(panel);

  const modal = document.createElement("div");
  modal.className = "mw-modal";
  modal.innerHTML = `
    <header>
      <h2>Input data</h2>
      <button id="toggle-modal" data-state="expanded">Minimize</button>
    </header>
    <div class="mw-body" id="input-list"></div>
    <div class="mw-collapsed" id="collapsed-summary" hidden>
      <span id="collapsed-label">No input selected</span>
      <button id="expand-modal">Expand</button>
    </div>
  `;
  modal.dataset.collapsed = "false";

  shadow.appendChild(panelWrapper);
  shadow.appendChild(modal);
  document.documentElement.appendChild(uiRoot);

  initModalDrag(modal);
  initPanelDrag(panelWrapper);

  panel.querySelector("#toggle-wand").addEventListener("click", () => {
    setWandState(!wandActive);
  });

  panel.querySelector("#toggle-auto").addEventListener("click", async () => {
    await setAutoNavigateState(!autoNavigate);
  });

  panel.querySelector("#mode-auto").addEventListener("click", () => {
    setWandMode(WAND_MODES.AUTO);
  });

  panel.querySelector("#mode-manual").addEventListener("click", () => {
    setWandMode(WAND_MODES.MANUAL);
  });

  panel.querySelector("#prev-row").addEventListener("click", () => navigateManual("back"));
  panel.querySelector("#next-row").addEventListener("click", () => navigateManual("forward"));
  const saveExitButton = panel.querySelector("#save-exit");
  saveExitButton.addEventListener("click", saveAndExit);
  saveExitButton.disabled = true;

  modal.querySelector("#toggle-modal").addEventListener("click", () => {
    toggleModalCollapsed(modal);
  });

  modal.querySelector("#expand-modal").addEventListener("click", () => {
    toggleModalCollapsed(modal, false);
  });
}

function updateUi() {
  if (!shadow) {
    return;
  }
  const rowInfo = shadow.getElementById("row-info");
  const toggleWand = shadow.getElementById("toggle-wand");
  const toggleAuto = shadow.getElementById("toggle-auto");
  const modeAutoBtn = shadow.getElementById("mode-auto");
  const modeManualBtn = shadow.getElementById("mode-manual");
  const manualNav = shadow.getElementById("manual-nav");
  const prevRow = shadow.getElementById("prev-row");
  const nextRow = shadow.getElementById("next-row");
  const inputList = shadow.getElementById("input-list");
  const collapsedSummary = shadow.getElementById("collapsed-summary");
  const collapsedLabel = shadow.getElementById("collapsed-label");
  const saveExitBtn = shadow.getElementById("save-exit");
  const hintText = wandMode === WAND_MODES.AUTO
    ? "Click text in the page to capture for this field."
    : "Highlight text, then press Ctrl+C or left-click to capture.";
  const totalRows = state?.totalRows ?? 0;
  const currentRowIndex = state?.currentRowIndex ?? 0;
  const currentInputIndex = state?.currentInputIndex ?? 0;

  toggleWand.textContent = wandActive ? "Enabled" : "Disabled";
  toggleWand.classList.toggle("primary", wandActive);
  toggleWand.classList.toggle("secondary", !wandActive);

  toggleAuto.textContent = autoNavigate ? "On" : "Off";
  toggleAuto.classList.toggle("primary", autoNavigate);
  toggleAuto.classList.toggle("secondary", !autoNavigate);

  modeAutoBtn.classList.toggle("active", wandMode === WAND_MODES.AUTO);
  modeManualBtn.classList.toggle("active", wandMode === WAND_MODES.MANUAL);
  modeAutoBtn.disabled = wandMode === WAND_MODES.AUTO;
  modeManualBtn.disabled = wandMode === WAND_MODES.MANUAL;

  if (!state || autoNavigate) {
    manualNav.hidden = true;
  } else {
    manualNav.hidden = false;
  }

  prevRow.disabled = !state || currentRowIndex <= 0;
  nextRow.disabled = !state || currentRowIndex >= Math.max(totalRows - 1, 0);

  rowInfo.textContent = state?.row?.indexValue ?? "No current row";

  inputList.innerHTML = "";
  const currentInput = state?.row?.inputs?.[currentInputIndex];
  collapsedLabel.textContent = currentInput?.column ?? state?.row?.indexValue ?? "No input selected";
  state?.row?.inputs?.forEach((input, index) => {
    const entry = document.createElement("div");
    entry.className = "mw-entry";
    entry.innerHTML = `
      <label>${input.column}</label>
      <textarea data-index="${index}">${input.value ?? ""}</textarea>
      <span class="mw-hint">${hintText}</span>
    `;
    entry.querySelector("textarea").addEventListener("change", (event) => {
      updateInputValue(index, event.target.value);
    });
    inputList.appendChild(entry);
  });

  if (saveExitBtn && saveExitBtn.dataset.pending !== "true") {
    saveExitBtn.disabled = !state;
  }
}

async function navigateManual(direction) {
  autoCollectService?.handleEvent?.("manual-navigate", { direction });
  const response = await extensionApi.runtime.sendMessage({
    type: MESSAGE_TYPES.NAVIGATE_MANUAL,
    payload: { direction }
  });
  if (!response?.ok) {
    alert(response?.error ?? "Unable to navigate.");
    return;
  }
  await refreshState();
}

async function saveAndExit() {
  const button = shadow?.getElementById("save-exit");
  if (button) {
    button.disabled = true;
    button.dataset.pending = "true";
  }
  try {
    const response = await extensionApi.runtime.sendMessage({ type: MESSAGE_TYPES.SAVE_AND_EXIT });
    if (!response?.ok) {
      throw new Error(response?.error ?? "Unable to save and exit the session.");
    }
    setWandState(false);
    if (response.state) {
      state = response.state;
      updateUi();
    } else {
      await refreshState();
    }
  } catch (error) {
    alert(error.message || "Failed to save progress.");
  } finally {
    if (button) {
      delete button.dataset.pending;
      if (!document.hidden) {
        button.disabled = !state;
      }
    }
  }
}

async function updateInputValue(index, value) {
  if (!state) {
    return;
  }
  const column = state.config.inputColumns[index];
  await extensionApi.runtime.sendMessage({
    type: MESSAGE_TYPES.UPDATE_INPUT_VALUE,
    payload: {
      rowIndex: state.currentRowIndex,
      column,
      value
    }
  });
  await refreshState();
}

async function refreshState() {
  const response = await extensionApi.runtime.sendMessage({ type: MESSAGE_TYPES.GET_STATE });
  if (!response?.ok) {
    return;
  }
  state = response.state ?? null;
  if (state && typeof state.autoNavigate === "boolean") {
    autoNavigate = state.autoNavigate;
  }
  updateUi();
  autoCollectService?.handleStateUpdate?.(state);
}

async function setAutoNavigateState(enabled) {
  const normalized = Boolean(enabled);
  if (autoNavigate === normalized) {
    return;
  }
  autoNavigate = normalized;
  updateUi();
  try {
    await extensionApi.runtime.sendMessage({
      type: MESSAGE_TYPES.SET_AUTO_NAVIGATE,
      payload: { enabled: normalized }
    });
  } catch (error) {
    console.warn("Magic Wand: failed to update auto navigate flag", error);
  }
}

function setWandMode(mode) {
  if (!mode || (mode !== WAND_MODES.AUTO && mode !== WAND_MODES.MANUAL)) {
    return;
  }
  if (wandMode === mode) {
    return;
  }
  wandMode = mode;
  if (wandActive) {
    document.documentElement.setAttribute("data-mw-wand", wandMode);
  }
  if (wandMode === WAND_MODES.MANUAL) {
    clearHighlight(lastHighlighted);
  }
  manualSelectionPending = false;
  manualSelectionText = "";
  updateUi();
  autoCollectService?.handleEvent?.("wand-mode", { mode: wandMode });
}

function setWandState(enabled) {
  if (wandActive === enabled) {
    return;
  }
  wandActive = enabled;
  if (wandActive) {
    document.documentElement.setAttribute("data-mw-wand", wandMode);
  } else {
    document.documentElement.removeAttribute("data-mw-wand");
    clearHighlight(lastHighlighted);
    manualSelectionPending = false;
    manualSelectionText = "";
  }
  updateUi();
  autoCollectService?.handleEvent?.("wand-toggle", { enabled: wandActive });
}

function highlightElement(target) {
  if (!target || target === lastHighlighted) {
    return;
  }
  if (uiRoot && (target === uiRoot || uiRoot.contains(target))) {
    return;
  }
  clearHighlight(lastHighlighted);
  target.classList.add("mw-highlight");
  lastHighlighted = target;
}

function clearHighlight(target) {
  if (!target) {
    lastHighlighted = null;
    return;
  }
  target.classList.remove("mw-highlight");
  if (target === lastHighlighted) {
    lastHighlighted = null;
  }
}

function toggleModalCollapsed(modal, force) {
  if (!modal) {
    return;
  }
  const toggleButton = modal.querySelector("#toggle-modal");
  const shouldCollapse = typeof force === "boolean"
    ? force
    : modal.dataset.collapsed !== "true";
  if (shouldCollapse) {
    modal.dataset.collapsed = "true";
    toggleButton.textContent = "Expand";
    toggleButton.dataset.state = "collapsed";
  } else {
    modal.dataset.collapsed = "false";
    toggleButton.textContent = "Minimize";
    toggleButton.dataset.state = "expanded";
  }
  updateUi();
}

async function captureValue(value, context = {}) {
  const normalized = typeof value === "string" ? value.trim() : String(value ?? "").trim();
  if (!normalized) {
    return;
  }
  const previousState = state
    ? {
        rowIndex: state.currentRowIndex,
        column: state.currentColumn,
        domain: getCurrentRowDomain(state),
        url: state.row?.url ?? null
      }
    : null;
  try {
    const response = await extensionApi.runtime.sendMessage({
      type: MESSAGE_TYPES.UPDATE_VALUE,
      payload: { value: normalized }
    });
    if (response?.ok) {
      if (!context.skipAutoCollectRecord) {
        autoCollectService?.handleEvent?.("capture-success", {
          value: normalized,
          column: previousState?.column ?? null,
          context,
          stateBefore: previousState
        });
      }
      await refreshState();
    }
  } catch (error) {
    // Surface capture issues in the console without disrupting the page.
    console.warn("Magic Wand: failed to capture value", error);
  }
}

function extractTargetText(target) {
  if (!target) {
    return "";
  }
  const tagName = target.tagName?.toLowerCase();
  if (tagName === "input" || tagName === "textarea") {
    return target.value?.trim() ?? "";
  }
  if (target.isContentEditable) {
    return target.innerText?.trim() ?? target.textContent?.trim() ?? "";
  }
  const text = target.innerText ?? target.textContent ?? "";
  return typeof text === "string" ? text.trim() : "";
}

function getSelectedText() {
  const selection = window.getSelection();
  if (selection) {
    const text = selection.toString();
    if (text && text.trim()) {
      return text.trim();
    }
  }
  const active = document.activeElement;
  if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA")) {
    const start = active.selectionStart;
    const end = active.selectionEnd;
    if (typeof start === "number" && typeof end === "number" && end > start) {
      return active.value.slice(start, end).trim();
    }
  }
  return "";
}

function resolveElementFromNode(node) {
  if (!node) {
    return null;
  }
  if (node.nodeType === Node.ELEMENT_NODE) {
    return node;
  }
  if (node.nodeType === Node.TEXT_NODE) {
    return node.parentElement ?? null;
  }
  return null;
}

function resolveElementFromSelection(selection) {
  if (!selection) {
    return null;
  }
  const anchorElement = resolveElementFromNode(selection.anchorNode);
  if (anchorElement) {
    return anchorElement;
  }
  const focusElement = resolveElementFromNode(selection.focusNode);
  if (focusElement) {
    return focusElement;
  }
  return null;
}

function getCurrentRowDomain(currentState = state) {
  const url = currentState?.row?.url;
  if (!url) {
    return null;
  }
  try {
    const parsed = new URL(url);
    return parsed.hostname ?? null;
  } catch (error) {
    return null;
  }
}

function clearCurrentSelection() {
  const selection = window.getSelection();
  if (selection && selection.rangeCount) {
    selection.removeAllRanges();
  }
  const active = document.activeElement;
  if (active && (active.tagName === "INPUT" || active.tagName === "TEXTAREA")) {
    const end = active.selectionEnd ?? active.value.length;
    try {
      active.setSelectionRange(end, end);
    } catch (error) {
      // Ignore selection reset issues for unsupported input types.
    }
  }
}

function resetManualSelection() {
  manualSelectionPending = false;
  manualSelectionText = "";
}

function isNodeInsideOverlay(node) {
  if (!uiRoot || !node) {
    return false;
  }
  if (node === uiRoot || node === shadow) {
    return true;
  }
  const root = node.getRootNode ? node.getRootNode() : null;
  if (root && root === shadow) {
    return true;
  }
  let current = node.nodeType === Node.ELEMENT_NODE ? node : node.parentElement;
  while (current) {
    if (current === uiRoot) {
      return true;
    }
    current = current.parentElement;
  }
  return false;
}

function handleSelectionChange() {
  if (!wandActive || wandMode !== WAND_MODES.MANUAL) {
    resetManualSelection();
    return;
  }
  const selection = window.getSelection();
  if (selection) {
    const anchor = selection.anchorNode;
    const focus = selection.focusNode;
    if (isNodeInsideOverlay(anchor) || isNodeInsideOverlay(focus)) {
      resetManualSelection();
      return;
    }
  }
  const text = getSelectedText();
  manualSelectionPending = Boolean(text);
  manualSelectionText = text;
}

function handleManualCopy(event) {
  if (!wandActive || wandMode !== WAND_MODES.MANUAL) {
    return;
  }
  const selection = window.getSelection();
  let element = null;
  if (selection) {
    const anchor = selection.anchorNode;
    const focus = selection.focusNode;
    if (isNodeInsideOverlay(anchor) || isNodeInsideOverlay(focus)) {
      return;
    }
    element = resolveElementFromSelection(selection);
  }
  const text = getSelectedText();
  if (!text) {
    resetManualSelection();
    return;
  }
  if (!element) {
    element = resolveElementFromNode(document.activeElement);
  }
  captureValue(text, {
    source: "manualCopy",
    element: element ?? null
  });
  manualSelectionPending = false;
  manualSelectionText = "";
}

function handleKeydown(event) {
  if (event.defaultPrevented) {
    return;
  }
  if (event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) {
    return;
  }
  if (event.target?.tagName === "INPUT" || event.target?.tagName === "TEXTAREA") {
    return;
  }
  if (event.target?.isContentEditable) {
    return;
  }
  if (event.key === "1") {
    setWandMode(WAND_MODES.AUTO);
    event.preventDefault();
    return;
  }
  if (event.key === "2") {
    setWandMode(WAND_MODES.MANUAL);
    event.preventDefault();
    return;
  }
  if (event.key === "3") {
    setWandState(!wandActive);
    event.preventDefault();
  }
}

function handleMouseMove(event) {
  if (!wandActive) {
    return;
  }
  if (wandMode !== WAND_MODES.AUTO) {
    clearHighlight(lastHighlighted);
    return;
  }
  const target = event.target;
  if (!target || target === document || target === window) {
    clearHighlight(lastHighlighted);
    return;
  }
  if (target === document.documentElement || target === document.body) {
    clearHighlight(lastHighlighted);
    return;
  }
  if (uiRoot && (target === uiRoot || uiRoot.contains(target))) {
    clearHighlight(lastHighlighted);
    return;
  }
  highlightElement(target);
}

async function handleClick(event) {
  const target = event.target;
  if (uiRoot && (target === uiRoot || uiRoot.contains(target))) {
    return;
  }
  if (!wandActive) {
    return;
  }

  if (wandMode === WAND_MODES.AUTO) {
    event.preventDefault();
    event.stopPropagation();
    const text = extractTargetText(target);
    if (!text) {
      return;
    }
    await captureValue(text, {
      source: "autoClick",
      element: target instanceof Element ? target : null
    });
    return;
  }

  if (wandMode === WAND_MODES.MANUAL) {
    if (!manualSelectionPending) {
      manualSelectionText = "";
      return;
    }
    const text = manualSelectionText || getSelectedText();
    if (!text) {
      resetManualSelection();
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    const selection = window.getSelection();
    const element = selection ? resolveElementFromSelection(selection) : null;
    await captureValue(text, {
      source: "manualSelection",
      element: element ?? (target instanceof Element ? target : null)
    });
    clearCurrentSelection();
    resetManualSelection();
  }
}

function attachListeners() {
  document.addEventListener("mousemove", handleMouseMove, true);
  document.addEventListener("click", handleClick, true);
  document.addEventListener("copy", handleManualCopy, true);
  document.addEventListener("selectionchange", handleSelectionChange, true);
  document.addEventListener("keydown", handleKeydown, true);
}

function initModalDrag(modal) {
  const header = modal.querySelector("header");
  const collapsed = modal.querySelector(".mw-collapsed");
  if (!header || !collapsed) {
    return;
  }

  const endDrag = (event) => {
    if (!dragState.active || event.pointerId !== dragState.pointerId) {
      return;
    }
    dragState.active = false;
    dragState.pointerId = null;
    dragState.target = null;
    modal.classList.remove("dragging");
    try {
      header.releasePointerCapture(event.pointerId);
    } catch (error) {
      // Ignore release errors.
    }
    try {
      collapsed.releasePointerCapture(event.pointerId);
    } catch (error) {
      // Ignore release errors.
    }
  };

  const startDrag = (event, source) => {
    if (event.button !== 0) {
      return;
    }
    if (event.pointerType === "touch" || event.pointerType === "pen") {
      return;
    }
    if (event.target && event.target.closest("button")) {
      return;
    }
    event.preventDefault();
    const rect = modal.getBoundingClientRect();
    dragState.active = true;
    dragState.pointerId = event.pointerId;
    dragState.offsetX = event.clientX - rect.left;
    dragState.offsetY = event.clientY - rect.top;
    dragState.target = modal;
    modal.style.right = "auto";
    modal.style.left = `${rect.left}px`;
    modal.style.top = `${rect.top}px`;
    modal.classList.add("dragging");
    source.setPointerCapture(event.pointerId);
  };

  const moveDrag = (event) => {
    if (!dragState.active || event.pointerId !== dragState.pointerId || dragState.target !== modal) {
      return;
    }
    const maxLeft = Math.max(0, window.innerWidth - modal.offsetWidth);
    const maxTop = Math.max(0, window.innerHeight - modal.offsetHeight);
    const left = Math.min(Math.max(0, event.clientX - dragState.offsetX), maxLeft);
    const top = Math.min(Math.max(0, event.clientY - dragState.offsetY), maxTop);
    modal.style.left = `${left}px`;
    modal.style.top = `${top}px`;
  };

  const attachDragHandlers = (source) => {
    source.addEventListener("pointerdown", (event) => startDrag(event, source));
    source.addEventListener("pointermove", moveDrag);
    source.addEventListener("pointerup", endDrag);
    source.addEventListener("pointercancel", endDrag);
  };

  attachDragHandlers(header);
  attachDragHandlers(collapsed);
}

function initPanelDrag(wrapper) {
  if (!wrapper) {
    return;
  }
  const panel = wrapper.querySelector(".mw-panel");
  if (!panel) {
    return;
  }

  const startDrag = (event) => {
    if (event.button !== 0) {
      return;
    }
    if (event.pointerType === "touch" || event.pointerType === "pen") {
      return;
    }
    const target = event.target;
    if (target && (target.tagName === "BUTTON" || target.closest("button"))) {
      return;
    }
    event.preventDefault();
    const rect = wrapper.getBoundingClientRect();
    dragState.active = true;
    dragState.pointerId = event.pointerId;
    dragState.offsetX = event.clientX - rect.left;
    dragState.offsetY = event.clientY - rect.top;
    dragState.target = wrapper;
    wrapper.style.right = "auto";
    wrapper.style.left = `${rect.left}px`;
    wrapper.style.top = `${rect.top}px`;
    panel.setPointerCapture(event.pointerId);
  };

  const moveDrag = (event) => {
    if (!dragState.active || event.pointerId !== dragState.pointerId || dragState.target !== wrapper) {
      return;
    }
    const maxLeft = Math.max(0, window.innerWidth - wrapper.offsetWidth);
    const maxTop = Math.max(0, window.innerHeight - wrapper.offsetHeight);
    const left = Math.min(Math.max(0, event.clientX - dragState.offsetX), maxLeft);
    const top = Math.min(Math.max(0, event.clientY - dragState.offsetY), maxTop);
    wrapper.style.left = `${left}px`;
    wrapper.style.top = `${top}px`;
  };

  const endDrag = (event) => {
    if (!dragState.active || event.pointerId !== dragState.pointerId) {
      return;
    }
    dragState.active = false;
    dragState.pointerId = null;
    dragState.target = null;
    try {
      panel.releasePointerCapture(event.pointerId);
    } catch (error) {
      // Ignore release errors.
    }
  };

  panel.addEventListener("pointerdown", startDrag);
  panel.addEventListener("pointermove", moveDrag);
  panel.addEventListener("pointerup", endDrag);
  panel.addEventListener("pointercancel", endDrag);
}

async function initAutoCollectFeature() {
  try {
    const response = await extensionApi.runtime.sendMessage({ type: MESSAGE_TYPES.GET_DEBUG_FLAGS });
    if (!response?.ok || !response.flags?.autoCollect) {
      return;
    }
    const moduleUrl = extensionApi.runtime.getURL("content/autoCollectService.js");
    const autoCollectModule = await import(moduleUrl);
    if (!autoCollectModule?.initAutoCollectService) {
      console.warn("Magic Wand: auto-collect service module missing init function");
      return;
    }
    const context = {
      extensionApi,
      shadowRoot: shadow,
      getState: () => state,
      getCurrentDomain: () => getCurrentRowDomain(state),
      captureValue: (value, metadata = {}) =>
        captureValue(value, { ...metadata, skipAutoCollectRecord: true }),
      refreshState,
      setAutoNavigate: setAutoNavigateState,
      navigateNext: () => navigateManual("forward"),
      navigatePrev: () => navigateManual("back"),
      setWandState,
      setWandMode,
      highlightElement,
      extractTextFromElement: extractTargetText,
      resolveElementFromNode,
      resolveElementFromSelection,
      getSelectedText,
      getUiRoot: () => uiRoot,
      getPanelWrapper: () => shadow?.querySelector(".mw-panel-wrapper") ?? null,
      getPanel: () => shadow?.querySelector(".mw-panel") ?? null,
      getControlsContainer: () => shadow?.querySelector(".mw-controls") ?? null
    };
    autoCollectService = await autoCollectModule.initAutoCollectService(context);
    if (state) {
      autoCollectService?.handleStateUpdate?.(state);
    }
  } catch (error) {
    console.warn("Magic Wand: failed to initialize auto-collect debug service", error);
  }
}

ensureUi();
attachListeners();
initAutoCollectFeature();
refreshState();
